$(document).ready(function() {
    $("#toggleloginPassword").click(function() {
        let password = $("#loginPassword");
        password.attr("type", this.checked ? "text" : "password")
    });

    $("#loginForm").submit(function(event) {
        event.preventDefault();

        let username = $("#loginUsername").val().trim();
        let password = $("#loginPassword").val().trim();
        let isValid = true;

        if (username === "") {
            $("#loginUsername").val("").attr("placeholder","Username is required!").addClass("usererror");
            isValid = false;
        }           
        
        if (password === "") {
            $("#loginPassword").val("").attr("placeholder","Password is required!").addClass("usererror");
            isValid = false;
        }

        if (isValid) {
            let users = JSON.parse(localStorage.getItem("users")) || [];
            let user = users.find(user => user.username === username && user.password === password);

            if (user) {
                localStorage.setItem("loggedInUser", username);
                alert("Login successful! Welcome  "+  username);
                window.location.href="../menu/menu.html";
            } else {
                $("#loginPassword").val("").attr("placeholder","Invalid username,password.").addClass("usererror");
            }
        }
    });
});
