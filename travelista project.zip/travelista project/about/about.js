 $(document).ready(function(){
    let loggedInUser = localStorage.getItem("loggedInUser");

    if (!loggedInUser) {
        alert("You are not logged in!");
        window.location.href="../login/login.html";
    }
    $("#aboutLogout").click(function(){
        console.log("clicked")
        localStorage.removeItem("loggedInUser");
        alert("Logged out successfully!");
        window.location.href = "../login/login.html";
    });
});
