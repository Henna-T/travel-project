$(document).ready(function(){
    let loggedInUser = localStorage.getItem("loggedInUser");

    if (!loggedInUser) {
        alert("You are not logged in!");
        window.location.href="../login/login.html";
    }

    $("#menuLogout").click(function(){
        localStorage.removeItem("loggedInUser");
        alert("Logged out successfully!");
        window.location.href = "../login/login.html";
    });

    $(".standrad-travel-button").click(function(){
        window.location.href = "../travelpages/standard/travelpage.html";
    })

    $(".premium-travel-button").click(function(){
        window.location.href = "../travelpages/premium/travelpage1.html";
    })
    
    $(".luxury-travel-button").click(function(){
        window.location.href = "../travelpages/luxury/travelpage3.html";
    })
});
