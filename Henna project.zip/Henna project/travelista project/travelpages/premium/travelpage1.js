$(document).ready(function () {
    $("#packageSelect option[value='Standard']").prop("disabled", true);
    $("#packageSelect option[value='Luxury']").prop("disabled", true);

    let packageDetails = {
        Standard: { type: "Standard", duration: "1 Day", price: 2000 },
        Premium: { type: "Premium", duration: "7 Days", price: 15000 },
        Luxury: { type: "Luxury", duration: "15 Days", price: 50000 }
    };

    let destinationDetails = {
        Meghalaya: "Shillong, visiting Elephant Falls, Ward’s Lake, and Shillong Peak. Then, head to Cherrapunji",
        Rajasthan: "Jaipur, visiting the grand Amer Fort, City Palace, Hawa Mahal, and Nahargarh Fort",
        Goa: "North Goa, visit Baga Beach, Calangute Beach, and Anjuna Beach",
        Manali: "Solang Valley – Adventure & Snow, Rohtang Pass, Nagar & Jana Waterfall"
    };

    $("#packageSelect, #numPeople").change(function () {
        let selectedPackage = $("#packageSelect").val();
        let numPeople = parseInt($("#numPeople").val());

        if (selectedPackage && !isNaN(numPeople) && numPeople > 0) {
            let pricePerHead = packageDetails[selectedPackage].price;
            let totalCost = pricePerHead * numPeople;
            $("#pricePerHead").val(`₹${pricePerHead}`);
            $("#totalPrice").val(`₹${totalCost}`);
        } else {
            $("#pricePerHead").val("");
            $("#totalPrice").val("");
        }
    });

    $("#dates").on("change", function () {
        let selectedDate = new Date($(this).val());
        let today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate < today) {
            $("#dateError").text("Please select an upcoming date!");
            $(this).val("");
        } else {
            $("#dateError").text("");
        }
    });

    $("#form2").submit(function (event) {
        event.preventDefault();

        const currentUser = localStorage.getItem("loggedInUser");
        if (!currentUser) {
            alert("User not logged in. Please log in again.");
            window.location.href="../../login/login.html";
            return;
        }

        let startingPlace = $("#startingPlace").val().trim();
        let numPeople = parseInt($("#numPeople").val());
        let selectedDate = $("#dates").val().trim();
        let selectedPackage = $("#packageSelect").val();
        let destination = $("#destinationSelect").val();

        if (!startingPlace || isNaN(numPeople) || numPeople <= 0 || !selectedDate || !selectedPackage || !destination) {
            alert("Please fill all fields correctly!");
            return;
        }

        let totalCost = packageDetails[selectedPackage].price * numPeople;
        let places = destinationDetails[destination];

        let bookings = JSON.parse(localStorage.getItem("bookings")) || [];

        let newBooking = {
            startingPlace: startingPlace,
            tripPeople: numPeople,
            tripDate: selectedDate,
            tripPackageType: packageDetails[selectedPackage].type,
            tripDuration: packageDetails[selectedPackage].duration,
            tripPrice: totalCost,
            tripDestination: destination,
            tripPlaces: places
        };

        let userBookingsKey = `bookings_${currentUser}`;
        let userBookings = JSON.parse(localStorage.getItem(userBookingsKey)) || [];
        userBookings.push(newBooking);
        localStorage.setItem(userBookingsKey, JSON.stringify(userBookings));

        alert(`Trip booked successfully! Total Cost: ₹${totalCost}`);
        window.location.href = "../../tripinfo/tripinfo.html";

    });          

    let loggedInUser = localStorage.getItem("loggedInUser");
        
    if (!loggedInUser) {
        alert("You are not logged in!");
        window.location.href="../../login/login.html";
    }
    
    $("#booking1Logout").click(function(){
        localStorage.removeItem("loggedInUser");
        alert("Logged out successfully!");
        window.location.href="../../login/login.html";
    });
});