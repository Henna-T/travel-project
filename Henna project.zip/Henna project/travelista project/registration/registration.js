$(document).ready(function() {
    $("#toggleRegisterPassword").click(function() {
        let password = $("#password");
        password.attr("type", this.checked ? "text" : "password")
    });

    $("#toggleRegisterPassword").click(function() {
        let password = $("#confirm");
        password.attr("type", this.checked ? "text" : "password")
    });

    $("#email").on("input", function () {
        let value = $(this).val().trim();
        $(this).val(value.replace(/\s/g, ""));
        $("#emailError").text(value.includes(" ") ? "No spaces allowed in email." : "");
    });

    $("#registerForm").submit(function(event) {
        event.preventDefault();

        let username = $("#username").val().trim();
        let email = $("#email").val().trim();
        let phone = $("#loginPhone").val().trim();
        let password = $("#password").val().trim();
        let confirm = $("#confirm").val().trim();

        let isValid = true;
        
        let usernameRegex = /^[A-Za-z ]{3,100}$/;
        if (!usernameRegex.test(username)) {
            $("#username").val("").attr("placeholder","Name must contain only alphabets,min 3 character,max upto 100.").addClass("usererror");
            isValid = false;
        }


        let phoneRegex = /^[0-9]{10}$/;
        if (!phoneRegex.test(phone)) {
            $("#loginPhone").val("").attr("placeholder","Phone number must be exactly 10 digits.").addClass("usererror");;
            isValid = false;
        }

        let emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
            $("#email").val("").attr("placeholder","Enter a valid email.").addClass("usererror");
            isValid = false;
        }


        let passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[\@\#\$\%\^\&\*\!]).{6,}$/;
        if (!passwordRegex.test(password)) {
            $("#password").val("").attr("placeholder","Password must be atleast 6 characters and include an uppercase,lowercase,special character").addClass("usererror");
            isValid = false;
        }

        if (confirm !== password) {
            $("#confirm").val("").attr("placeholder","Passwords do not match.").addClass("usererror");
            isValid = false;
        }

        if (isValid) {
            let users = JSON.parse(localStorage.getItem("users")) || [];
            let existingUser = users.some(user => user.email === email);

            if (existingUser) {
                $("#email").val("").attr("placeholder","Email already registered! Use another email.").addClass("usererror");
            } else {
                users.push({ username, email, phone, password });
                localStorage.setItem("users", JSON.stringify(users));
                alert("Registration successful!");
                window.location.href = "../login/login.html";
            }
        }
    });
});
