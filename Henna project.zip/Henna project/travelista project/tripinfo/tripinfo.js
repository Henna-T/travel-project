$(document).ready(function () {
    const currentUser = localStorage.getItem("loggedInUser");

    if (!currentUser) {
        alert("No user logged in. Redirecting to login page...");
        window.location.href="../login/login.html"; 
        return;
    }

    const bookingsKey = "bookings_" + currentUser;
    const bookings = JSON.parse(localStorage.getItem(bookingsKey)) || [];

    if (bookings.length === 0) {
        $("#tripList").html(`
            <tr>
                <td colspan='8' style='text-align: center; font-weight: bold; color: red;'>
                    No trips booked yet!
                </td>
            </tr>`);
    } else {
        bookings.forEach(trip => {
            $("#tripList").append(`
                <tr>
                    <td>${trip.startingPlace}</td>
                    <td>${trip.tripPeople}</td>
                    <td>${trip.tripDate}</td>
                    <td>${trip.tripPackageType}</td>
                    <td>${trip.tripDuration}</td>
                    <td>${trip.tripDestination}</td>
                    <td>${trip.tripPlaces || "Not specified"}</td>
                    <td>₹${trip.tripPrice}</td>
                </tr>
            `);
        });
    }

    $("#infoLogout").click(function(){
        localStorage.removeItem("loggedInUser");
        alert("Logged out successfully!");
        window.location.href = "../login/login.html";
    });
});